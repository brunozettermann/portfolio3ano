document.getElementById("sistemas").addEventListener("click", function() {
    window.location.href = "sistemass.html";
});

document.getElementById("modelagem").addEventListener("click", function() {
    window.location.href = "modelagem.html";
});
document.getElementById("software").addEventListener("click", function() {
    window.location.href = "softwares.html";
});