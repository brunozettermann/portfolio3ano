document.getElementById("inicio").addEventListener("click", function() {
    window.location.href = "index.html";
});